from flask import Flask, render_template, request, redirect, url_for
from flask_mysqldb import MySQL

app = Flask(__name__)

# MySQL Configuration
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'monisha@3009'  # Update with your MySQL password
app.config['MYSQL_DB'] = 'travel_bookings'

mysql = MySQL(app)

@app.route('/', methods=['GET', 'POST'])
def index():
    message = ''
    if request.method == 'POST':
        # Fetch form data
        name = request.form['name']
        email = request.form['email']
        starting_point = request.form['starting-point']
        destination = request.form['destination']
        departure_date = request.form['departure-date']
        return_date = request.form['return-date']
        payment_method = request.form['payment-method']

        # Insert data into the database
        cursor = mysql.connection.cursor()
        cursor.execute(
            'INSERT INTO bookings (name, email, starting_point, destination, departure_date, return_date, payment_method) '
            'VALUES (%s, %s, %s, %s, %s, %s, %s)',
            (name, email, starting_point, destination, departure_date, return_date, payment_method)
        )
        mysql.connection.commit()
        cursor.close()

        message = 'Booking Successful!'

    return render_template('booking_form.html', message=message)

@app.route('/view_bookings')
def view_bookings():
    # Fetch all bookings from the database
    cursor = mysql.connection.cursor()
    cursor.execute('SELECT * FROM bookings')
    bookings = cursor.fetchall()
    cursor.close()

    return render_template('view_bookings.html', bookings=bookings)

if __name__ == '__main__':
    app.run(debug=True)
